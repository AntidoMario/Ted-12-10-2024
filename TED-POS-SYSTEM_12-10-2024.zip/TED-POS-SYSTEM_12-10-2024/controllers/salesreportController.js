const db = require('../models');
const { Order, OrderItem, products, Bundles, User } = db; 

const getSalesReport = async (startDate, endDate) => {
  try {
    
    // If both startDate and endDate are provided, we will convert them to Date objects.
    // Start of the start date (00:00:00) and end of the end date (23:59:59)
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      // Set the time for start date to 00:00:00
      start.setHours(0, 0, 0, 0);

      // Set the time for end date to 23:59:59
      end.setHours(23, 59, 59, 999);

      // Use Sequelize's Op.between for filtering the date range
      const orders = await db.Order.findAll({
        where: {
          date_created: {
            [db.Sequelize.Op.between]: [start, end]  // Filtering the date_created field between start and end
          }
        },
        attributes: ['orders_id','date_created', 'ref_num', 'or_num', 'total_items', 'total_amount']
      });

      return orders.map(order => ({
        orders_id: order.orders_id,
        date_created: order.date_created.toISOString(),
        ref_num: order.ref_num,
        or_num: order.or_num,
        total_items: order.total_items,  // Directly use total_items from the orders table
        total_amount: order.total_amount,
      }));
    }

    // If no date range is selected, return all orders
    const orders = await db.Order.findAll({
      attributes: ['orders_id', 'date_created', 'ref_num', 'or_num', 'total_items', 'total_amount']
    });

    return orders.map(order => ({
      orders_id: order.orders_id,
      date_created: order.date_created.toISOString(),
      ref_num: order.ref_num,
      or_num: order.or_num,
      total_items: order.total_items,
      total_amount: order.total_amount,
    }));
    
  } catch (error) {
    console.error("Error fetching sales report:", error);
    throw error;
  }
};

const getsalesOrderDetails = async (req, res) => {
  const { id } = req.params;

  try {
    const order = await Order.findOne({
      where: { orders_id: id },
      include: [
        {
          model: OrderItem,
          attributes: ['quantity', 'amount', 'product_id', 'bundle_id'],
          include: [
            {
              model: products,
              attributes: ['product_name'],
              as: 'Product',
            },
            {
              model: Bundles,
              attributes: ['bundle_name'],
              as: 'Bundle',
            },
          ],
        },
        {
          model: User,
          attributes: ['name'],
        },
      ],
    });

    if (!order) {
      return res.status(404).json({ error: "Order not found." });
    }

    // Prepare the response data
    const responseData = {
      date_created: order.date_created.toISOString(),
      ref_num: order.ref_num,
      or_num: order.or_num,
      total_amount: order.total_amount,
      amount_rendered: order.amount_rendered,
      change_amount: order.change_amount,
      total_items: order.total_items,
      User: order.User,
      OrderItems: order.OrderItems.map(item => ({
        quantity: item.quantity,
        amount: item.amount,
        product_name: item.product_id ? item.Product?.product_name : item.Bundle?.bundle_name,
      })),
    };
    

    res.json(responseData);
  } catch (error) {
    console.error("Error fetching order details:", error);
    res.status(500).json({ error: "Internal server error." });
  }
};

const getTopEntitiesSequelize = async () => {
  try {
    // Fetch grouped totals for product_id
    const productTotals = await OrderItem.findAll({
      attributes: [
        ['product_id', 'entity_id'], // Alias to match combined format
        [db.Sequelize.literal("'Product'"), 'entity_type'], // Literal for entity type
        [db.Sequelize.fn('SUM', db.Sequelize.col('quantity')), 'total_quantity'],
        [db.Sequelize.fn('SUM', db.Sequelize.col('amount')), 'total_sales'], // Total sales amount
      ],
      where: {
        product_id: { [db.Sequelize.Op.ne]: null }, // Exclude null product_id
      },
      group: ['product_id'],
      raw: true,
    });

    // Fetch grouped totals for bundle_id
    const bundleTotals = await OrderItem.findAll({
      attributes: [
        ['bundle_id', 'entity_id'], // Alias to match combined format
        [db.Sequelize.literal("'Bundle'"), 'entity_type'], // Literal for entity type
        [db.Sequelize.fn('SUM', db.Sequelize.col('quantity')), 'total_quantity'],
        [db.Sequelize.fn('SUM', db.Sequelize.col('amount')), 'total_sales'], // Total sales amount
      ],
      where: {
        bundle_id: { [db.Sequelize.Op.ne]: null }, // Exclude null bundle_id
      },
      group: ['bundle_id'],
      raw: true,
    });

    // Combine and sort the results by total quantity
    const combinedResults = [...productTotals, ...bundleTotals].sort(
      (a, b) => b.total_quantity - a.total_quantity
    );

    // Extract top 3 products and top 3 bundles separately
    const topProducts = productTotals
      .sort((a, b) => b.total_quantity - a.total_quantity)
      .slice(0, 3);

    const topBundles = bundleTotals
      .sort((a, b) => b.total_quantity - a.total_quantity)
      .slice(0, 3);

    // Enrich top entities with product and bundle details
    const enrichedTopProducts = await Promise.all(
      topProducts.map(async (product) => {
        const details = await products.findOne({
          where: { product_id: product.entity_id },
          attributes: ['product_img', 'product_name', 'product_model'],
          raw: true,
        });
        return { ...product, ...details };
      })
    );

    const enrichedTopBundles = await Promise.all(
      topBundles.map(async (bundle) => {
        const details = await Bundles.findOne({
          where: { bundle_id: bundle.entity_id },
          attributes: ['bundle_image', 'bundle_name'],
          raw: true,
        });
        return { ...bundle, ...details };
      })
    );

    // Log top entities
    console.log('Top Products:', enrichedTopProducts);
    console.log('Top Bundles:', enrichedTopBundles);

    return { topProducts: enrichedTopProducts, topBundles: enrichedTopBundles };
  } catch (error) {
    console.error("Error fetching top entities with Sequelize:", error);
    throw error;
  }
};




module.exports = {
  getSalesReport, getsalesOrderDetails, getTopEntitiesSequelize
};
