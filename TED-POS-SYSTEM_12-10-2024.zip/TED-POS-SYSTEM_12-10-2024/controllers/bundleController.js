// controllers/bundleController.js
const db = require('../models');
const { Bundle, Product, BundleProduct } = require('../models');

exports.getProducts = async (req, res) => {
  try {
    const products = await db.products.findAll();
    res.json(products); // Return products as JSON
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).send('Internal server error');
  }
};

exports.saveBundle = async (req, res) => {
  const { bundle_name, discount, bundle_description, product_ids, total_price, bundle_status } = req.body;

  console.log("Received data:", req.body); // Log the received data

  // Validate required fields
  if (!bundle_name || !total_price || !product_ids) {
      return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
      // Create a new bundle entry
      const newBundle = await db.Bundles.create({
          bundle_name,
          bundle_image: req.file ? req.file.filename : null, // Save the uploaded file name
          bundle_description,
          total_price,
          discount: discount || 0, // Default discount to 0 if not provided
          bundle_status: bundle_status ? 'Available' : 'Unavailable', // Set status based on input
          product_ids: JSON.parse(product_ids) // Ensure this is parsed correctly
      });

      // Parse product_ids and associate products with the bundle
      const productIds = JSON.parse(product_ids);
      await newBundle.addProducts(productIds); // Use the association method to add products

      // Respond with success message
      res.status(201).json({ message: 'Bundle Successfully Added', bundle: newBundle });
  } catch (error) {
      console.error("Error saving bundle:", error); // Log the error
      res.status(500).json({ error: 'Internal server error' });
  }
};

exports.updateBundle = async (req, res) => {
  const bundleId = req.params.id; // Get the bundle ID from the request parameters
  const { bundle_name, discount, bundle_description, product_ids, total_price, bundle_status } = req.body;

  console.log("Received data for update:", req.body); // Log the received data

  try {
    // Find the existing bundle
    const existingBundle = await db.Bundles.findByPk(bundleId);
    if (!existingBundle) {
      return res.status(404).json({ error: 'Bundle not found' });
    }

    // Update only the fields that are provided in the request body
    if (bundle_name) existingBundle.bundle_name = bundle_name;
    if (bundle_description) existingBundle.bundle_description = bundle_description;
    if (total_price) existingBundle.total_price = total_price;
    if (discount) existingBundle.discount = discount; // Update discount if provided
    if (bundle_status !== undefined) {
      existingBundle.bundle_status = (bundle_status === 'true' || bundle_status === true) ? 'Available' : 'Unavailable'; // Update status based on input
    }
    if (product_ids) existingBundle.product_ids = JSON.parse(product_ids); // Ensure this is parsed correctly

    // Check if a new image is uploaded
    if (req.file) {
      existingBundle.bundle_image = req.file.filename; // Save the uploaded file name
    }

    // Save the updated bundle
    await existingBundle.save();

    // Parse product_ids and associate products with the bundle
    if (product_ids) {
      const productIds = JSON.parse(product_ids);
      await existingBundle.setProducts(productIds); // Use the association method to set products
    }

    // Respond with success message
    res.status(200).json({ message: 'Bundle Successfully Updated', bundle: existingBundle });
  } catch (error) {
    console.error("Error updating bundle:", error); // Log the error
    res.status(500).json({ error: 'Internal server error' });
  }
};