async function fetchAndDisplayDashboardData() {
  try {
    const response = await fetch('/dashboard/data');
    if (!response.ok) {
      throw new Error(`Failed to fetch dashboard data: ${response.statusText}`);
    }
    
    const data = await response.json();

    // Update counts
    document.getElementById('categoriesCount').textContent = data.categoriesCount || 0;
    document.getElementById('productsCount').textContent = data.productsCount || 0;
    document.getElementById('suppliersCount').textContent = data.suppliersCount || 0;
    document.getElementById('bundlesCount').textContent = data.bundlesCount || 0;
    document.getElementById('usersCount').textContent = data.usersCount || 0;
    document.getElementById('totalOrdersCount').textContent = data.totalOrdersCount || 0;

    // Update sales
    document.getElementById('todaysSales').textContent = `₱${(data.todaysSales || 0).toLocaleString()}`;
    document.getElementById('totalSales').textContent = `₱${(data.totalSales || 0).toLocaleString()}`;

    // Initialize the chart after fetching data
    initializeChart(data);

  } catch (error) {
    console.error('Error fetching dashboard data:', error);
  }
}

// Function to initialize the Apex chart
async function initializeChart() {
  // Fetch the sales data for the last 7 days
  const salesData = await fetchDailySalesData();

  // Extract days and sales amounts
  const categories = salesData.map((item, index) => `Day ${index + 1}`); // X-axis: Days 1-7
  const salesValues = salesData.map((item) => item.total_sales); // Y-axis: Sales amounts

  // Create the chart
  var options = {
    series: [{
      name: 'Daily Sales (₱)',
      data: salesValues
    }],
    chart: {
      height: 350,
      type: 'line'
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'smooth'
    },
    xaxis: {
      categories: categories, // Days 1-7 or specific dates
      title: { text: "Days" }
    },
    yaxis: {
      title: { text: "Sales Amount (₱)" },
      min: 0, // Ensures Y-axis starts at 0
      labels: {
        formatter: function (value) {
          return `₱${value.toLocaleString()}`; // Format large numbers
        }
      }
    },
    tooltip: {
      x: {
        format: 'yyyy-MM-dd'
      },
    },
  };
  

  // Render the chart
  const chartContainer = document.querySelector("#chart");
  chartContainer.innerHTML = ""; // Clear any existing chart
  const chart = new ApexCharts(chartContainer, options);
  chart.render();
}


// Call the function when the page loads
document.addEventListener('DOMContentLoaded', fetchAndDisplayDashboardData);

// Slider functionality
document.addEventListener("DOMContentLoaded", function () {
  const infoData = document.querySelector(".info-data");
  const cards = document.querySelectorAll(".info-data .card");
  const prevButton = document.querySelector(".slider-nav .prev");
  const nextButton = document.querySelector(".slider-nav .next");

  let currentIndex = 0;
  const cardWidth = cards[0].offsetWidth + 20; // card width plus gap

  function updateSlider() {
    infoData.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
  }

  nextButton.addEventListener("click", () => {
    if (currentIndex < cards.length - 1) {
      currentIndex++;
      updateSlider();
    }
  });

  prevButton.addEventListener("click", () => {
    if (currentIndex > 0) {
      currentIndex--;
      updateSlider();
    }
  });
});

// Progress bar functionality
const allProgress = document.querySelectorAll('main .card .progress');

allProgress.forEach(item => {
  item.style.setProperty('--value', item.dataset.value);
});

async function fetchDailySalesData() {
  try {
    const response = await fetch('/dashboard/daily-sales');
    if (!response.ok) {
      throw new Error(`Failed to fetch daily sales data: ${response.statusText}`);
    }

    const salesData = await response.json();
    return salesData; // Returns the daily sales data
  } catch (error) {
    console.error("Error fetching daily sales data:", error);
    return [];
  }
}

