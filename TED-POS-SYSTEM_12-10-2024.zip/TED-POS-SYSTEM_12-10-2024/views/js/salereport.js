document.addEventListener('DOMContentLoaded', function () {
  

  // Define the populateTable function to populate the sales report table
  function populateTable(orders, grandTotal) {
    const orderTableBody = document.getElementById('order-table-body');
    const totalRow = document.getElementById('total-row');
    const grandTotalCell = document.getElementById('grand-total');

    // Clear the existing table body
    orderTableBody.innerHTML = '';

    // Populate the table with new data
    orders.forEach(order => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${new Date(order.date_created).toLocaleDateString()}</td>
        <td>${order.ref_num}</td>
        <td>${order.or_num}</td>
        <td>${order.total_items || 0}</td>
        <td>₱${(order.total_amount || 0).toFixed(2)}</td>
        <td><button class="view-receipt-btn" data-id="${order.orders_id}">View Receipt</button></td>
      `;
      orderTableBody.appendChild(row);
    });

    // Update the grand total
    grandTotalCell.textContent = `₱${grandTotal.toFixed(2)}`;

    // Show or hide the total row based on whether there are orders
    totalRow.style.display = orders.length > 0 ? '' : 'none';

    // Add event listeners to view receipt buttons
    document.querySelectorAll('.view-receipt-btn').forEach(button => {
      button.addEventListener('click', function () {
        const orderId = this.getAttribute('data-id');
        console.log('Order ID:', orderId); // Debugging line
        openReceiptModal(orderId); // Pass the order ID to fetch the details
      });
    });

  }

  // Load receipt details into the modal
  async function loadReceiptDetails(orderId) {
    try {
      const response = await fetch(`/salesreport/${orderId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch receipt details');
      }
  
      const order = await response.json();
      if (!order || !order.OrderItems) {
        throw new Error('Invalid order data received.');
      }
  
      // Populate modal fields with order details
      document.getElementById("cashier-name").textContent = order.User?.name || 'N/A';
      document.getElementById("receipt-date").textContent = new Date(order.date_created).toLocaleString();
      document.getElementById("invoice-no").textContent = order.ref_num || 'N/A';
      document.getElementById("official-receipt-no").textContent = order.or_num || 'N/A';

  
      // Clear and populate receipt items
      const receiptItems = document.getElementById("receipt-items").querySelector("tbody");
      receiptItems.innerHTML = '';
  
      order.OrderItems.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${item.product_name || 'N/A'}</td>
          <td>${item.quantity}</td>
          <td>₱${item.amount.toFixed(2)}</td>
        `;
        receiptItems.appendChild(row);
      });
  
      // Update totals
      document.getElementById("subtotal").textContent = `₱${order.total_amount.toFixed(2)}`;
      document.getElementById("cash-rendered").textContent = `₱${order.amount_rendered.toFixed(2)}`;
      document.getElementById("change-amount").textContent = `₱${order.change_amount.toFixed(2)}`;
    } catch (error) {
      console.error('Error loading receipt details:', error.message);
    }
  }
  

  // Open the receipt modal
  function openReceiptModal(orderId) {
    if (!orderId) {
      console.error('Order ID is undefined');
      return;
    }
  
    console.log('Opening modal for Order ID:', orderId);  // Add this line for debugging
    
    const modal = document.getElementById('receipt-modal');
    modal.style.display = 'flex'; // Show the modal
  
    // Fetch and populate receipt details
    loadReceiptDetails(orderId);
  }
  
  

  // Close modal event listener
  document.querySelector('.close-btn').addEventListener('click', function () {
    document.getElementById('receipt-modal').style.display = 'none';
  });

  document.getElementById("cancelBtn").addEventListener("click", () => {
    document.getElementById("receipt-modal").style.display = "none";
  });

  // Fetch initial sales report data
  fetch('/salesreport')
    .then(response => response.json())
    .then(data => {
      populateTable(data.orders, data.grandTotal);
    })
    .catch(error => {
      console.error('Error fetching sales report:', error);
    });

  // Apply filter functionality
  document.getElementById('apply-filter').addEventListener('click', function () {
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;

    if (startDate && endDate) {
      const params = new URLSearchParams({ start_date: startDate, end_date: endDate });

      fetch(`/salesreport?${params.toString()}`)
        .then(response => response.json())
        .then(data => {
          populateTable(data.orders, data.grandTotal);
        })
        .catch(error => {
          console.error('Error fetching filtered sales report:', error);
        });
    } else {
      alert('Please select both start and end dates');
    }
  });

  // Reset filter functionality
  document.getElementById('reset-filter').addEventListener('click', function () {
    document.getElementById('start-date').value = '';
    document.getElementById('end-date').value = '';

    fetch('/salesreport')
      .then(response => response.json())
      .then(data => {
        populateTable(data.orders, data.grandTotal);
      })
      .catch(error => {
        console.error('Error fetching sales report:', error);
      });
  });

  // Print table functionality
  document.querySelector('.print-button').addEventListener('click', function () {
    const table = document.querySelector('.report-table');
    if (!table) {
      alert('No data to print.');
      return;
    }

    // Hide the Action column (last column)
    const actionColumn = table.querySelectorAll('th:nth-child(6), td:nth-child(6)');
    actionColumn.forEach(cell => cell.style.display = 'none');

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Sales Report</title>
          <style>
            table {
              width: 100%;
              border-collapse: collapse;
              margin: 20px 0;
            }
            th, td {
              border: 1px solid black;
              padding: 8px;
              text-align: center;
            }
            th {
              background-color: #f2f2f2;
            }
          </style>
        </head>
        <body>
          <h2 style="text-align: center;">Sales Report</h2>
          ${table.outerHTML}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();

    // Restore the Action column
    actionColumn.forEach(cell => cell.style.display = '');
  });

  // Export table to CSV functionality
// Export table to CSV functionality
document.querySelector('.export-button').addEventListener('click', function () {
  const table = document.querySelector('.report-table');
  if (!table) {
    alert('No data available to export.');
    return;
  }

  let csvContent = '';
  const rows = table.querySelectorAll('tr');

  rows.forEach(row => {
    const cells = row.querySelectorAll('th, td');
    const rowData = Array.from(cells).map((cell, index) => {
      // Exclude the 6th column (index 5)
      if (index !== 5) {
        return `"${cell.textContent.replace(/"/g, '""')}"`; // Escape quotes in text content
      }
      return ''; // Empty string for the excluded column
    }).filter(cell => cell !== ''); // Filter out the excluded column

    csvContent += rowData.join(',') + '\n';
    });

    const csvBlob = new Blob([`\ufeff${csvContent}`], { type: 'text/csv;charset=utf-8;' });
    const csvUrl = URL.createObjectURL(csvBlob);
    const tempLink = document.createElement('a');
    tempLink.href = csvUrl;
    tempLink.setAttribute('download', 'SalesReport.csv');
    tempLink.click();
  });


  // Fetch initial sales report data
fetch('/salesreport')
.then(response => response.json())
.then(data => {
  populateTable(data.orders, data.grandTotal);
  populateTopEntities(data.topProducts, data.topBundles); // Populate top entities
})
.catch(error => {
  console.error('Error fetching sales report:', error);
});

// Function to populate top products and bundles
function populateTopEntities(topProducts, topBundles) {
const topProductsBody = document.getElementById('top-products-body');
const topBundlesBody = document.getElementById('top-bundles-body');

// Clear existing data
topProductsBody.innerHTML = '';
topBundlesBody.innerHTML = '';

// Populate top products
topProducts.forEach(product => {
  const row = document.createElement('tr');
  row.innerHTML = `
    <td><img src="/uploads/${product.product_img}" alt="${product.product_name}" style="width: 50px; height: 50px;"></td>
    <td>${product.product_name}</td>
    <td>${product.product_model}</td>
    <td>${product.total_quantity}</td>
    <td>₱${product.total_sales.toFixed(2)}</td>
  `;
  topProductsBody.appendChild(row);
});

// Populate top bundles
topBundles.forEach(bundle => {
  const row = document.createElement('tr');
  row.innerHTML = `
    <td><img src="/uploads/${bundle.bundle_image}" alt="${bundle.bundle_name}" style="width: 50px; height: 50px;"></td>
    <td>${bundle.bundle_name}</td>
    <td>${bundle.total_quantity}</td>
    <td>₱${bundle.total_sales.toFixed(2)}</td>
  `;
  topBundlesBody.appendChild(row);
});
}
});
