$(document).ready(function() {
  // Fetch products and display them
  function fetchProductData() {
    $.ajax({
      url: '/products/list', // Adjust to your route for fetching products
      method: 'GET',
      success: function (data) {
        originalProducts = data;
        allProducts = [...originalProducts];
        totalProducts = allProducts.length;
        displayPage(currentPage);
      },
      error: function (xhr) {
        alert('Error fetching product data: ' + xhr.responseText);
      },
    });
  }

  // Fetch and populate categories for the dropdown
  function fetchCategories() {
    $.ajax({
      url: '/categories/list', // Adjust to your backend route for fetching categories
      method: 'GET',
      success: function (categories) {
        const categoryFilter = $('#categoryFilter');
        categoryFilter.empty(); // Clear existing options

        // Add "Select All" option
        categoryFilter.append('<option value="all">Select All</option>');

        // Populate categories
        categories.forEach(category => {
          categoryFilter.append(`<option value="${category.category_id}">${category.category_name}</option>`);
        });

        // Initialize Select2
        categoryFilter.select2({
          placeholder: 'Select a Category',
          allowClear: true,
        });
      },
      error: function (xhr) {
        alert('Error fetching categories: ' + xhr.responseText);
      },
    });
  }
  
    // Pagination variables
    let currentPage = 1;
    let rowsPerPage = 3; // Default value
    let totalProducts = 0;
    let allProducts = [];
    let originalProducts = [];
  
    // Display products for the current page
  function displayPage(page) {
    const productList = $('#productList');
    productList.empty(); // Clear existing rows

    const start = (page - 1) * rowsPerPage;
    const end = Math.min(start + rowsPerPage, totalProducts);

    for (let i = start; i < end; i++) {
      const product = allProducts[i];
      const row = `
        <tr>
          <td>${product.product_id}</td>
          <td><img src="/uploads/${product.product_img}" alt="${product.product_name}" style="width: 50px; height: auto;" /></td>
          <td>${product.category ? product.category.category_name : 'N/A'}</td>
          <td>${product.product_name}</td>
          <td>${product.product_model}</td>
          <td>${product.selling_price}</td>
          <td>${product.product_quantity}</td>
          <td>${product.product_status || 'Active'}</td>
        </tr>
      `;
      productList.append(row);
    }

    // Update pagination info
    $('.table-footer p').text(`Showing ${start + 1} to ${end} of ${totalProducts} entries`);
    $('.btn-pagination').prop('disabled', page === 1); // Disable previous button if on first page
    $('.btn-pagination').last().prop('disabled', end === totalProducts); // Disable next button if on last page
  }
  
    // Event listener for pagination buttons
    $('.btn-pagination').first().click(() => {
      if (currentPage > 1) {
        currentPage--;
        displayPage(currentPage);
      }
    });
  
    $('.btn-pagination').last().click(() => {
      if (currentPage * rowsPerPage < totalProducts) {
        currentPage++;
        displayPage(currentPage);
      }
    });
  
    // Change rows per page dynamically
    $('#show-entries').change(function () {
      rowsPerPage = parseInt(this.value, 10);
      currentPage = 1; // Reset to first page
      displayPage(currentPage);
    });
  
    // Search functionality
    $('.search-box input').on('input', function () {
      const searchTerm = this.value.toLowerCase();
  
      if (searchTerm) {
        allProducts = originalProducts.filter(product =>
          product.product_name.toLowerCase().includes(searchTerm) ||
          product.product_model.toLowerCase().includes(searchTerm) ||
          (product.category && product.category.category_name.toLowerCase().includes(searchTerm))
        );
      } else {
        allProducts = [...originalProducts];
      }
  
      totalProducts = allProducts.length;
      currentPage = 1; // Reset to first page
      displayPage(currentPage);
    });

    // Filter products by category
  $('#categoryFilter').change(function () {
    const selectedCategory = $(this).val();

    if (selectedCategory === 'all') {
      allProducts = [...originalProducts]; // Reset to all products
    } else {
      allProducts = originalProducts.filter(
        product => product.category && product.category.category_id === parseInt(selectedCategory, 10)
      );
    }

    totalProducts = allProducts.length;
    currentPage = 1; // Reset to the first page
    displayPage(currentPage);
  });
  
    // Call the function to fetch product data when the page loads
    fetchCategories(); // Populate category dropdown
    fetchProductData();
  });