document.addEventListener("DOMContentLoaded", () => {
  const modal = document.getElementById("receipt-modal");
  const closeBtn = document.querySelector(".close-btn");
  const ordersTbody = document.getElementById("orders-tbody");
  const entriesSelect = document.getElementById("entries");
  const searchInput = document.getElementById("search");
  const pagination = document.querySelector(".pagination");

  let orders = []; // To store all fetched orders
  let currentPage = 1;
  let entriesPerPage = 5;
  let filteredOrders = [];

  // Fetch orders from the server
  // Fetch orders from the server
const fetchOrders = async () => {
  try {
      const response = await fetch('/orders/list');
      if (!response.ok) {
          throw new Error('Network response was not ok');
      }
      orders = await response.json();

      // Sort orders by date_created in descending order
      orders.sort((a, b) => new Date(b.date_created) - new Date(a.date_created));

      filteredOrders = [...orders];
      renderOrders();
      updatePagination();
  } catch (error) {
      console.error("Error fetching orders:", error);
  }
};

// Render orders in the table
const renderOrders = () => {
  ordersTbody.innerHTML = ''; // Clear existing rows
  const startIndex = (currentPage - 1) * entriesPerPage;
  const endIndex = startIndex + entriesPerPage;
  const currentOrders = filteredOrders.slice(startIndex, endIndex);

  currentOrders.forEach((order, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${startIndex + index + 1}</td> <!-- Ascending row number -->
      <td>${new Date(order.date_created).toLocaleDateString()}</td>
      <td>${order.ref_num}</td>
      <td>${order.total_items}</td>
      <td>${order.total_amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
      <td>
        <button class="bx bx-show view-icon" data-id="${order.orders_id}"></button>
        <button class="bx bx-edit edit-icon" data-id="${order.orders_id}"></button>
      </td>
    `;
    ordersTbody.appendChild(row);
  });

  addPrintButtonListeners(); // Add event listeners to "View" and "Edit" buttons
};



  // Update pagination
  const updatePagination = () => {
    pagination.innerHTML = ''; // Clear existing pagination

    const totalPages = Math.ceil(filteredOrders.length / entriesPerPage);

    const prevSpan = document.createElement('span');
    prevSpan.textContent = 'Previous';
    prevSpan.className = currentPage === 1 ? 'disabled' : '';
    prevSpan.addEventListener('click', () => {
      if (currentPage > 1) {
        currentPage--;
        renderOrders();
        updatePagination();
      }
    });
    pagination.appendChild(prevSpan);

    const nextSpan = document.createElement('span');
    nextSpan.textContent = 'Next';
    nextSpan.className = currentPage === totalPages ? 'disabled' : '';
    nextSpan.addEventListener('click', () => {
      if (currentPage < totalPages) {
        currentPage++;
        renderOrders();
        updatePagination();
      }
    });
    pagination.appendChild(nextSpan);
  };

  // Search orders
  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase();
    filteredOrders = orders.filter(
      (order) =>
        order.ref_num.toLowerCase().includes(query) ||
        order.orders_id.toString().includes(query)
    );
    currentPage = 1;
    renderOrders();
    updatePagination();
  });

  // Change entries per page
  entriesSelect.addEventListener('change', (e) => {
    entriesPerPage = parseInt(e.target.value, 10);
    currentPage = 1;
    renderOrders();
    updatePagination();
  });

  // Add event listeners to the "View" buttons
  const addPrintButtonListeners = () => {
    const printButtons = document.querySelectorAll(".view-icon");
    printButtons.forEach((button) => {
      button.addEventListener("click", () => {
        modal.style.display = "flex";
        const orderId = button.getAttribute('data-id');
        loadReceiptDetails(orderId);
      });
    });

    const editButtons = document.querySelectorAll(".edit-icon");
    editButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const orderId = button.getAttribute('data-id');
            window.location.href = `/editorders?id=${orderId}`; // Redirect to edit page with order ID
        });
    });
  };

  // Load receipt details
const loadReceiptDetails = async (orderId) => {
  try {
    const response = await fetch(`/orders/${orderId}`);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const order = await response.json();

    // Set cashier name
    document.getElementById("cashier-name").textContent = order.User.name;

    // Set date, invoice number, and official receipt number
    document.getElementById("receipt-date").textContent = new Date(order.date_created).toLocaleString();
    document.getElementById("invoice-no").textContent = order.ref_num;
    document.getElementById("official-receipt-no").textContent = order.or_num;

    // Clear previous receipt items
    const receiptItems = document.getElementById("receipt-items").querySelector("tbody");
    receiptItems.innerHTML = '';

    // Populate receipt items
    order.OrderItems.forEach((item) => {
      let productName = 'N/A';
      if (item.product_id && item.Product) {
        productName = item.Product.product_name;
      } else if (item.bundle_id && item.Bundle) {
        productName = item.Bundle.bundle_name;
      }

      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${productName}</td>
        <td>${item.quantity}</td>
        <td>${item.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
      `;
      receiptItems.appendChild(row);
    });

    // Set totals
    document.getElementById("subtotal").textContent = order.total_amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById("cash-rendered").textContent = order.amount_rendered.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById("change-amount").textContent = order.change_amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  } catch (error) {
    console.error("Error loading receipt details:", error);
  }
};
  // Close modal
  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  window.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.style.display = "none";
    }
  });

  // Print button click event
  document.getElementById("printBtn").addEventListener("click", () => {
    const content = document.querySelector(".receipt").innerHTML;
    const printWindow = window.open("", "", "height=500, width=800");
    printWindow.document.write('<html><head><title>Receipt</title></head><body>');
    printWindow.document.write(content);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
  });

  // Fetch orders when the page loads
  fetchOrders();
});
