module.exports = (sequelize, DataTypes) => {
  const OrderItem = sequelize.define('OrderItem', {
      order_items_id: { 
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
      },
      quantity: DataTypes.INTEGER, // Total items
      price: DataTypes.FLOAT, // Total price
      amount: {
        type: DataTypes.FLOAT, // Total price for the products/bundles in this order item
        allowNull: false, // Ensure it is always calculated and saved
    },    
    orders_id: { // This should match the foreign key in the Orders table
        type: DataTypes.INTEGER,
        allowNull: false,
    },
      product_id: {
        type: DataTypes.INTEGER, // Change from JSON to INTEGER
        allowNull: true,
    },
    bundle_id: {
        type: DataTypes.INTEGER, // Change from JSON to INTEGER
        allowNull: true,
    },
  }, {});

  OrderItem.associate = (models) => {
    OrderItem.belongsTo(models.Order, { foreignKey: 'orders_id' });    
    OrderItem.belongsTo(models.products, { foreignKey: 'product_id', as: 'Product' }); // Ensure alias is defined
    OrderItem.belongsTo(models.Bundles, { foreignKey: 'bundle_id', as: 'Bundle' }); // Ensure alias is defined
};

  return OrderItem;
};  